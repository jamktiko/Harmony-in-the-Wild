using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameData
{
    public List<string> questData;
    public List<bool> abilityData;
    public List<float> playerPositionData;
}

/*public enum GameDataType
{
    QuestData,
    AbilityData
}*/
